<div class="tutorSchedule">
    <div class="container">
        <div class="flexRow d-flex">
            <div class="column-1">
                <div class="tutorSchedule-left common-shadow">
                    <div id="scheduleCalendar" ></div>
                    <div id="pickCalHj" style="display:none"></div>
                    <div class="text text-center d-flex align-items-center justify-content-center font-bd">
                        <span class="dot"></span>
                            <span>{{__('labels.available_classes')}}</span>
                    </div>
                </div>
            </div>
            
            <div class="column-2" id="classList">
                
            </div>
        </div>
    </div>
</div>