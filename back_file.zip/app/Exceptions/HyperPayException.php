<?php

namespace App\Exceptions;

use Exception;

/**
 * Class HyperPayException
 */
class HyperPayException extends Exception
{

}
