<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BankTranslation extends Model
{
    protected $fillable = [
        'bank_name'
    ];
}
