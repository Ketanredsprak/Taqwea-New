<?php

namespace App\Exceptions;

use Exception;

class ClassCancelTimeOverException extends Exception
{

}
