<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassSubTopicTranslation extends Model
{
    protected $fillable = [
        'sub_topic'
    ];
}
